package MyProject;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Calculaor extends util {

	WebDriver driver;
	
	@BeforeSuite
	public void launch_Browser(){
		
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		
		driver.get("https://www.calculator.net/");
		
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
	}
	
	//Multiplication-
	@Test(priority=1)
	public void multiplication() throws InterruptedException{
		
		String n1 = "423", n2 = "525";
				
		click_Element(driver, n1);
				
		driver.findElement(By.xpath("//span[text()='×']")).click();
				
		click_Element(driver, n2);
				
		WebElement res_Text = driver.findElement(By.xpath("//div[@id='sciOutPut']"));
		System.out.println(n1 + " × " + n2 + " is " + res_Text.getText());
				
		Thread.sleep(2000);
		driver.findElement(By.xpath("//span[text()='AC']")).click();		
	}
	
	//Division-
	@Test(priority=2)
	public void division() throws InterruptedException{
		
		String n1 = "4000", n2 = "200";
				
		click_Element(driver, n1);
						
		driver.findElement(By.xpath("//span[text()='/']")).click();
					
		click_Element(driver, n2);
				
		WebElement res_Text = driver.findElement(By.xpath("//div[@id='sciOutPut']"));
		System.out.println(n1 + " / " + n2 + " is " + res_Text.getText());
			
		Thread.sleep(2000);
		driver.findElement(By.xpath("//span[text()='AC']")).click();
	}
	
	//Addition-
	@Test(priority=3)
	public void addition() throws InterruptedException{
		
		String n1 = "-234234", n2 = "345345";
			
		click_Element(driver, n1);
						
		driver.findElement(By.xpath("//span[text()='+']")).click();
						
		click_Element(driver, n2);
			
		WebElement res_Text = driver.findElement(By.xpath("//div[@id='sciOutPut']"));
		System.out.println(n1 + " + " + n2 + " is " + res_Text.getText());
				
		Thread.sleep(2000);
		driver.findElement(By.xpath("//span[text()='AC']")).click();
	}
	
	//Subtraction-
	@Test(priority=3)
	public void subtract() throws InterruptedException{
		
		String n1 = "234823", n2 = "-23094823";
		
		click_Element(driver, n1);
						
		driver.findElement(By.xpath("//span[contains(text(),'–')]")).click();
						
		click_Element(driver, n2);
		
		WebElement res_Text = driver.findElement(By.xpath("//div[@id='sciOutPut']"));
		System.out.println(n1 + " - " + n2 + " is " + res_Text.getText());
				
		Thread.sleep(2000);
		driver.findElement(By.xpath("//span[text()='AC']")).click();
	}
	
	@AfterSuite
	public void close_Browser(){
		
		driver.close();
	}
}
