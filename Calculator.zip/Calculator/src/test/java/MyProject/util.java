package MyProject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class util {

		public static void click_Element(WebDriver driver, String num){
		
		String[] arr = num.split("");
				
		for(int i=0; i<arr.length; i++){
			
			String ch = arr[i];
			
			if (ch.equals("-")) {
				
				driver.findElement(By.xpath("//span[contains(text(),'–')]")).click();
				
			}else {
				
				WebElement ele = driver.findElement(By.xpath("//span[text()='"+ ch +"']"));
				ele.click();
								
			}
		}
	}
}